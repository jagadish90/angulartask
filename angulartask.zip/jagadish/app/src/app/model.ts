export class model {

    username:any;
    name:any;
    email:any;
    usertype:any;
    password:any;
    mobile:any;
    address:any;
    
} 